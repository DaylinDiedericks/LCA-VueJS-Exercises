<template>
  <h1>🍳 Cooking Masterclass Checkout</h1>

  <div class="container">

    <div class="catalogue">
      <h2>Courses</h2>

      <div class="course-grid">
        <CourseCard
          v-for="course in courses"
          :key="course.id"
          :course="course"
          @add-course="addToCart"
        />
      </div>
    </div>

    <div class="cart-section">
      <Cart
        :cart="cart"
        @increase="increaseQuantity"
        @decrease="decreaseQuantity"
        @remove="removeItem"
      />

      <PriceSummary
        :subtotal="subtotal"
        :tax="tax"
        :total="grandTotal"
      />
    </div>

  </div>
</template>

<script setup>
import { ref, computed } from "vue";

import CourseCard from "./components/CourseCard.vue";
import Cart from "./components/Cart.vue";
import PriceSummary from "./components/PriceSummary.vue";

const courses = ref([
  {
    id: 1,
    name: "American styled Burger Masterclass",
    price: 450,
    soldOut: false,
  },
  {
    id: 2,
    name: "Seafood Paela Masterclass",
    price: 600,
    soldOut: false,
  },
  {
    id: 3,
    name: "Sushi Rolling Masterclass",
    price: 350,
    soldOut: false,
  },
  {
    id: 4,
    name: "Nandos Peri-Peri Chicken Masterclass",
    price: 700,
    soldOut: true,
  },
  {
    id: 5,
    name: "Barbeque Masterclass",
    price: 500,
    soldOut: false,
  },
  {
    id: 6,
    name: "Halal Style Cooking",
    price: 400,
    soldOut: false,
  },
]);

const cart = ref([]);

function addToCart(course) {
  const item = cart.value.find((c) => c.id === course.id);

  if (item) {
    item.quantity++;
  } else {
    cart.value.push({
      ...course,
      quantity: 1,
    });
  }
}

function increaseQuantity(id) {
  const item = cart.value.find((c) => c.id === id);

  if (item) {
    item.quantity++;
  }
}

function decreaseQuantity(id) {
  const item = cart.value.find((c) => c.id === id);

  if (item && item.quantity > 1) {
    item.quantity--;
  }
}

function removeItem(id) {
  cart.value = cart.value.filter((c) => c.id !== id);
}

const subtotal = computed(() => {
  return cart.value.reduce((total, item) => {
    return total + item.price * item.quantity;
  }, 0);
});

const tax = computed(() => {
  return subtotal.value * 0.15;
});

const grandTotal = computed(() => {
  return subtotal.value + tax.value;
});
</script>