<template>
  <div class="cart">
    <h2>Shopping Cart</h2>

    <p v-if="cart.length === 0">Your cart is empty.</p>

    <CartItem
      v-for="item in cart"
      :key="item.id"
      :item="item"
      @increase="$emit('increase', item.id)"
      @decrease="$emit('decrease', item.id)"
      @remove="$emit('remove', item.id)"
    />
  </div>
</template>

<script setup>
import CartItem from "./CartItem.vue";

defineProps({
  cart: Array,
});

defineEmits(["increase", "decrease", "remove"]);
</script>