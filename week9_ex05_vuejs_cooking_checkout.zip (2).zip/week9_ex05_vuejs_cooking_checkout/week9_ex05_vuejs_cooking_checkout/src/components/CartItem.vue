<template>
  <div class="cart-item">
    <h3>{{ item.name }}</h3>

    <p>Price: R{{ item.price }}</p>

    <div>
      <button @click="$emit('decrease')">-</button>
      <span> {{ item.quantity }} </span>
      <button @click="$emit('increase')">+</button>
    </div>

    <p>Line Total: R{{ item.price * item.quantity }}</p>

    <button class="remove-btn" @click="$emit('remove')">
      Remove
    </button>
  </div>
</template>

<script setup>
defineProps({
  item: Object,
});

defineEmits(["increase", "decrease", "remove"]);
</script>